#ifndef XC_HEADER_TEMPLATE_H
#define	XC_HEADER_TEMPLATE_H

#include <xc.h> // include processor files - each processor file is guarded.  

unsigned char ler_teclado(void);

#endif	/* XC_HEADER_TEMPLATE_H */

