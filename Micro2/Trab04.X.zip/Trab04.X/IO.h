
#ifndef IO
#define	IO

#include <xc.h> // include processor files - each processor file is guarded.  
void setup(void);
void setup_io(void);


#endif	/* XC_HEADER_TEMPLATE_H */

